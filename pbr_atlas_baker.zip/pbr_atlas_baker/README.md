# PBR Atlas Baker

A Blender add-on that bakes **Base Color / Roughness / Metallic / Normal /
Displacement** from any number of selected objects onto one shared UV atlas,
merges the results into a handful of combined PNG textures, and wires them
into a single new shared material — automatically.

Instead of manually creating a new UV map, packing it, baking each object,
and combining textures by hand, this add-on does the whole pipeline in one
click.

## Features

- Bakes multiple objects into one shared texture atlas (instead of one
  texture per object).
- Bakes every material slot on an object, not just the active one - a
  single object with several materials (body, eyes, metal trim, etc.)
  contributes all of them to the atlas.
- Supports up to 5 channels: Base Color, Roughness, Metallic, Normal,
  Displacement.
- Automatically creates and packs a new UV map without touching your
  original UV layout.
- Produces at most 5 final PNG files, no matter how many objects you baked.
- Builds a ready-to-use shared material and assigns it to every baked
  object.
- Adjustable resolution (512–4096) and UV pack margin.

## Requirements

- Blender 4.2 or newer (older versions may work but are not officially
  tested).
- A GPU or CPU capable of running Cycles.
- NumPy, which ships with Blender's own Python by default.

---

## 1. Installation

**[Screenshot 1 — the Blender Preferences > Add-ons window, before installing]**

1. Download the add-on's `.zip` file (do not unzip it).
2. In Blender, go to **Edit > Preferences > Add-ons**.
3. Click **Install...** and select the downloaded `.zip` file.

**[Screenshot 2 — the add-on listed in the Add-ons panel with its checkbox]**

4. Enable the checkbox next to **PBR Atlas Baker** to activate it.

**[Screenshot 3 — the Atlas Baker tab open in the 3D Viewport sidebar]**

5. In the 3D Viewport, press **N** to open the sidebar, then click the
   **Atlas Baker** tab. The panel should now be visible.

---

## 2. Usage

**[Screenshot 4 — objects selected in the viewport, ready to bake]**

1. Select the objects you want to bake. Every object must be a **Mesh**
   with an existing UV map and a node-based material.

**[Screenshot 5 — the panel with Output Directory, UV name, and resolution filled in]**

2. In the panel, set:
   - **Output Directory** — where the final PNGs will be saved.
   - **New UV Name** — name of the atlas UV map that will be created.
   - **File Base Name** — prefix used for the output file names.
   - **Resolution** — 512, 1024, 2048, or 4096.
   - **UV Pack Margin** — spacing between UV islands.

**[Screenshot 6 — the Channels box with checkboxes for each map]**

3. Tick the channels you want baked: **Base Color**, **Roughness**,
   **Metallic**, **Normal**, **Displacement**.

**[Screenshot 7 — the "Also Keep Per-Object Bakes" checkbox]**

4. (Optional) Enable **Also Keep Per-Object Bakes** if you also want each
   object's individual bake saved to disk, in addition to the combined
   atlas. Off by default.

**[Screenshot 8 — clicking the "Bake Atlas" button]**

5. Click **Bake Atlas** and wait for the process to finish. Progress can be
   seen at the bottom-right of the Blender window.

**[Screenshot 9 — the finished result: combined textures in the output folder]**

6. When it's done, check your output folder — you'll have up to 5 combined
   PNG files (one per channel), e.g. `Atlas_BaseColor.png`,
   `Atlas_Roughness.png`, `Atlas_Normal.png`.

**[Screenshot 10 — the new shared material applied to all objects in the viewport]**

7. All baked objects are automatically assigned one new shared material
   that reads the combined textures through the new atlas UV.

---

## How it works internally

- Each object keeps its original UV map untouched; a second, new UV map is
  created alongside it and packed together with every other selected
  object's new UV, into one shared 0–1 atlas space.
- Baking reads source textures through the **original** UV (so texture
  content stays correct) while writing results into the **new, packed**
  UV (so islands land in the right place in the atlas).
- Base Color / Roughness / Metallic are baked only if directly connected to
  the matching Principled BSDF input.
- Normal is only recognized through the standard
  Principled → Normal Map → Image Texture chain, and baked with Blender's
  NORMAL bake type.
- Displacement is read from whatever feeds the Material Output's
  Displacement socket, even through several intermediate nodes.
- Every object's bake is merged into a running combined canvas and freed
  right away, so memory use stays roughly constant regardless of how many
  objects you bake.

## Known limitations

- Baking requires Cycles; the render engine is switched automatically and
  restored afterwards.
- Large resolutions (2048/4096) combined with many objects will take
  noticeably longer and use more GPU/CPU resources.
- Always try it on a copy of your scene first.

## Credits & Disclosure

This add-on was developed with the assistance of AI (Claude, Anthropic) for
writing and debugging the code, under the direction and testing of the
author. Every part of the logic — UV handling, baking, and the memory
optimizations described above — was reviewed, tested, and fixed through
several rounds of real-world testing in Blender before being published
here. The source code is fully open and included in this repository, so
you can read through it yourself before installing.
