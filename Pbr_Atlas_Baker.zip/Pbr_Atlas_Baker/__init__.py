bl_info = {
    "name": "PBR Atlas Baker",
    "author": "Claude (Anthropic)",
    "version": (2, 2, 0),
    "blender": (3, 6, 0),
    "location": "View3D > Sidebar (N) > Atlas Baker",
    "description": "Bake Base Color / Roughness / Metallic / Normal / Displacement from multiple objects onto one shared UV atlas, merge them into a handful of combined PNGs, and wire them into a new shared material.",
    "category": "Material",
}

import bpy
import os
from bpy.props import (
    StringProperty,
    EnumProperty,
    FloatProperty,
    BoolProperty,
    PointerProperty,
)
from bpy.types import PropertyGroup, Panel, Operator

try:
    import numpy as np
    HAS_NUMPY = True
except ImportError:
    HAS_NUMPY = False


# ---------------------------------------------------------------------------
# Helper functions for reading node-tree connections
# ---------------------------------------------------------------------------

def get_principled_node(mat):
    if not mat or not mat.use_nodes:
        return None
    for n in mat.node_tree.nodes:
        if n.type == 'BSDF_PRINCIPLED':
            return n
    return None


def get_output_node(mat):
    for n in mat.node_tree.nodes:
        if n.type == 'OUTPUT_MATERIAL' and n.is_active_output:
            return n
    for n in mat.node_tree.nodes:
        if n.type == 'OUTPUT_MATERIAL':
            return n
    return None


def get_direct_source(node, socket_name):
    """
    Returns only a direct connection (no node in between).
    Used for Base Color / Roughness / Metallic, since by convention no
    intermediate node is allowed between the Image Texture and the
    Principled BSDF input.
    """
    if node is None:
        return None
    inp = node.inputs.get(socket_name)
    if inp is None or not inp.is_linked:
        return None
    link = inp.links[0]
    return link.from_node, link.from_socket


def get_normal_source(principled):
    """
    Special-cased rule for normals:
    Principled.Normal -> Normal Map -> Image Texture (Color)
    Only that one intermediate node (Normal Map) is allowed.
    """
    if principled is None:
        return None
    inp = principled.inputs.get('Normal')
    if inp is None or not inp.is_linked:
        return None
    nmap_node = inp.links[0].from_node
    if nmap_node.type != 'NORMAL_MAP':
        return None
    color_in = nmap_node.inputs.get('Color')
    if color_in is None or not color_in.is_linked:
        return None
    return nmap_node


def wire_temp_source_uv(nt, uv_name, exclude_node=None):
    """
    Temporarily connect a UV Map node (pointing at uv_name) into the Vector
    input of every Image Texture node in this tree that has no explicit
    Vector connection. Without this, such nodes silently fall back to the
    object's *active* UV map - which during baking is the freshly packed
    atlas UV, not the UV the source texture was actually authored for. That
    mismatch is what scrambles the baked result even though the atlas UV
    packing itself is correct.
    Returns (uv_node, [sockets_we_connected]) so it can be undone with
    unwire_temp_source_uv() right after the bake.
    """
    uv_node = nt.nodes.new('ShaderNodeUVMap')
    uv_node.uv_map = uv_name
    connected = []
    for n in nt.nodes:
        if n.type != 'TEX_IMAGE' or n is exclude_node:
            continue
        vec_in = n.inputs.get('Vector')
        if vec_in is not None and not vec_in.is_linked:
            nt.links.new(uv_node.outputs['UV'], vec_in)
            connected.append(vec_in)
    return uv_node, connected


def unwire_temp_source_uv(nt, uv_node, connected):
    for vec_in in connected:
        for l in list(vec_in.links):
            nt.links.remove(l)
    nt.nodes.remove(uv_node)


def get_displacement_source(mat):
    """
    Checks the Displacement input on the Material Output node.
    Unlike Base Color/Roughness/Metallic, intermediate nodes are fine here;
    we simply return whatever socket feeds Displacement directly
    (even if that socket is itself fed by several nodes upstream).
    """
    out = get_output_node(mat)
    if out is None:
        return None
    inp = out.inputs.get('Displacement')
    if inp is None or not inp.is_linked:
        return None
    link = inp.links[0]
    return link.from_node, link.from_socket


SUFFIX = {
    'base_color': 'BaseColor',
    'roughness': 'Roughness',
    'metallic': 'Metallic',
    'normal': 'Normal',
    'displacement': 'Displacement',
}


# ---------------------------------------------------------------------------
# Property Group
# ---------------------------------------------------------------------------

class AtlasBakeProperties(PropertyGroup):
    output_dir: StringProperty(
        name="Output Directory",
        subtype='DIR_PATH',
        default="//textures/",
    )
    new_uv_name: StringProperty(
        name="New UV Name",
        default="AtlasUV",
    )
    image_base_name: StringProperty(
        name="File Base Name",
        default="Atlas",
    )
    resolution: EnumProperty(
        name="Resolution",
        items=[
            ('512', "512", ""),
            ('1024', "1024", ""),
            ('2048', "2048", ""),
            ('4096', "4096", ""),
        ],
        default='2048',
    )
    pack_margin: FloatProperty(
        name="UV Pack Margin",
        default=0.01,
        min=0.0,
        max=1.0,
    )
    bake_base_color: BoolProperty(name="Base Color", default=True)
    bake_roughness: BoolProperty(name="Roughness", default=True)
    bake_metallic: BoolProperty(name="Metallic", default=True)
    bake_normal: BoolProperty(name="Normal", default=True)
    bake_displacement: BoolProperty(name="Displacement", default=True)
    keep_object_images: BoolProperty(
        name="Also Keep Per-Object Bakes",
        description="In addition to the combined atlas PNGs, also save each "
                    "object's individual baked image to disk",
        default=False,
    )


# ---------------------------------------------------------------------------
# Main Operator
# ---------------------------------------------------------------------------

class ATLASBAKE_OT_run(Operator):
    bl_idname = "atlasbake.run"
    bl_label = "Bake Atlas"
    bl_description = "Bake all selected objects onto one shared UV atlas and combine each channel into a single PNG"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        if not HAS_NUMPY:
            self.report(
                {'ERROR'},
                "NumPy is not available in this Blender's Python - image "
                "combining cannot run."
            )
            return {'CANCELLED'}

        props = context.scene.atlas_bake_props
        self._props = props

        objs = [o for o in context.selected_objects if o.type == 'MESH']
        if not objs:
            self.report({'ERROR'}, "No mesh objects selected.")
            return {'CANCELLED'}
        if not props.output_dir:
            self.report({'ERROR'}, "Output directory is not set.")
            return {'CANCELLED'}

        out_dir = bpy.path.abspath(props.output_dir)
        os.makedirs(out_dir, exist_ok=True)
        res = int(props.resolution)
        new_uv_name = props.new_uv_name or "AtlasUV"
        base_name = props.image_base_name or "Atlas"

        scene = context.scene
        original_engine = scene.render.engine
        original_active = context.view_layer.objects.active
        original_selected = list(context.selected_objects)

        channel_data = {}
        saved_files = []

        try:
            # Baking is only reliable with Cycles -> switch temporarily if needed
            if scene.render.engine != 'CYCLES':
                scene.render.engine = 'CYCLES'

            # ---------------------------------------------------------
            # Step 1: add a fresh atlas UV alongside each object's original
            # UV map (initialized as a copy of it). The ORIGINAL UV map is
            # kept, not deleted - source textures still need to be sampled
            # through it during baking. Only the atlas UV becomes active /
            # active-render, since that's the one Step 2 packs and the one
            # the bake should write its output into.
            # ---------------------------------------------------------
            valid_objs = []
            for obj in objs:
                uvs = obj.data.uv_layers
                original_uv = uvs.active
                if original_uv is None:
                    self.report({'WARNING'}, f"{obj.name} has no UV map, skipped.")
                    continue

                # remove any extra UV maps, keep only the currently active one
                for uv in list(uvs):
                    if uv != original_uv:
                        uvs.remove(uv)

                # create the new atlas UV (Blender initializes its coordinates
                # from the current active UV as a starting point)
                new_uv = uvs.new(name=new_uv_name)

                new_uv.active = True
                new_uv.active_render = True

                valid_objs.append(obj)

            if not valid_objs:
                self.report({'ERROR'}, "No valid objects (with a UV map) remain.")
                return {'CANCELLED'}

            # ---------------------------------------------------------
            # Step 2: pack all the new atlas UVs together in one shared
            # operation (a single common atlas).
            # ---------------------------------------------------------
            bpy.ops.object.select_all(action='DESELECT')
            for obj in valid_objs:
                obj.select_set(True)
            context.view_layer.objects.active = valid_objs[0]

            bpy.ops.object.mode_set(mode='EDIT')
            for obj in valid_objs:
                obj.data.uv_layers.active = obj.data.uv_layers[new_uv_name]
            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.uv.select_all(action='SELECT')
            bpy.ops.uv.pack_islands(margin=props.pack_margin, rotate=True)
            bpy.ops.object.mode_set(mode='OBJECT')

            # ---------------------------------------------------------
            # Step 3: bake every enabled channel for every object.
            # Results are kept in memory only (nothing is saved to disk
            # yet) so they can be merged first.
            # ---------------------------------------------------------
            for obj in valid_objs:
                mat = obj.active_material
                if mat is None or not mat.use_nodes:
                    self.report({'WARNING'}, f"{obj.name} has no valid node-based material, skipped.")
                    continue
                self.bake_object(context, obj, mat, new_uv_name, res, base_name, props, channel_data, out_dir)

            # baking is done with every object - the original UV map (kept
            # around purely so source textures could be sampled correctly)
            # can now be dropped, leaving only the atlas UV on each mesh.
            for obj in valid_objs:
                for uv in list(obj.data.uv_layers):
                    if uv.name != new_uv_name:
                        obj.data.uv_layers.remove(uv)

            # ---------------------------------------------------------
            # Step 4: turn each channel's running canvas (already merged,
            # object by object, as baking happened) into a real image and
            # save it. No large lists of per-object images to clean up here
            # anymore - that cleanup already happened incrementally in
            # _merge_and_free.
            # ---------------------------------------------------------
            combined_images = {}
            for key, entry in channel_data.items():
                combined_name = f"{base_name}_{SUFFIX[key]}"
                combined = self._finalize_canvas(entry['canvas'], entry['colorspace'], combined_name, res)
                self._save_image(combined, out_dir)
                saved_files.append(combined.name + ".png")
                combined_images[key] = combined

            # ---------------------------------------------------------
            # Step 5: build one shared material from the combined atlas
            # images and assign it to every baked object, replacing
            # whatever material(s) it had before.
            # ---------------------------------------------------------
            if combined_images:
                shared_mat = self._build_atlas_material(base_name, new_uv_name, combined_images)
                for obj in valid_objs:
                    obj.data.materials.clear()
                    obj.data.materials.append(shared_mat)
                    obj.active_material_index = 0
            else:
                self.report({'WARNING'}, "No channel was baked - nothing to combine.")

        finally:
            scene.render.engine = original_engine
            bpy.ops.object.select_all(action='DESELECT')
            for o in original_selected:
                o.select_set(True)
            context.view_layer.objects.active = original_active

        if saved_files:
            self.report(
                {'INFO'},
                f"Atlas bake finished. Saved {len(saved_files)} combined image(s): {', '.join(saved_files)}"
            )
        return {'FINISHED'}

    # -------------------------------------------------------------
    # Bake one object: every enabled channel, into temporary
    # per-object images that get merged later.
    # -------------------------------------------------------------
    def bake_object(self, context, obj, mat, uv_name, res, base_name, props, channel_data, out_dir):
        principled = get_principled_node(mat)

        # The mesh still carries both UV maps at this point (see Step 1):
        # the atlas UV (uv_name) and whichever original UV it started with.
        # We need the original one's name so source textures can be forced
        # to sample through it during baking instead of the active atlas UV.
        original_uv_name = next(
            (uv.name for uv in obj.data.uv_layers if uv.name != uv_name),
            uv_name,
        )

        # --- Base Color / Roughness / Metallic (direct connection only) ---
        direct_channels = [
            ('base_color', props.bake_base_color, 'Base Color', 'sRGB'),
            ('roughness', props.bake_roughness, 'Roughness', 'Non-Color'),
            ('metallic', props.bake_metallic, 'Metallic', 'Non-Color'),
        ]
        for key, enabled, socket_name, colorspace in direct_channels:
            if not enabled:
                continue
            src = get_direct_source(principled, socket_name)
            if src is None:
                # this channel isn't directly connected for this object -> skip
                continue
            src_node, src_socket = src
            img_name = f"{obj.name}_{base_name}_{SUFFIX[key]}"
            img = self._new_image(img_name, res, colorspace)
            self.bake_channel_emit(context, obj, mat, src_socket, img, uv_name, original_uv_name)
            self._merge_and_free(key, img, res, colorspace, channel_data, out_dir, props)

        # --- Normal (only one Normal Map node allowed, bake type=NORMAL) ---
        if props.bake_normal:
            nmap_node = get_normal_source(principled)
            if nmap_node is not None:
                img_name = f"{obj.name}_{base_name}_{SUFFIX['normal']}"
                img = self._new_image(img_name, res, 'Non-Color')
                self.bake_normal_type(context, obj, mat, img, uv_name, original_uv_name)
                self._merge_and_free('normal', img, res, 'Non-Color', channel_data, out_dir, props)

        # --- Displacement (connected to Material Output, intermediates OK) ---
        if props.bake_displacement:
            src = get_displacement_source(mat)
            if src is not None:
                src_node, src_socket = src
                img_name = f"{obj.name}_{base_name}_{SUFFIX['displacement']}"
                img = self._new_image(img_name, res, 'Non-Color')
                self.bake_channel_emit(context, obj, mat, src_socket, img, uv_name, original_uv_name)
                self._merge_and_free('displacement', img, res, 'Non-Color', channel_data, out_dir, props)

    # -------------------------------------------------------------
    # Create a blank RGBA image, forced fully transparent so unbaked
    # areas stay transparent even before the bake's own clear pass.
    # -------------------------------------------------------------
    def _new_image(self, name, res, colorspace):
        existing = bpy.data.images.get(name)
        if existing is not None:
            bpy.data.images.remove(existing)
        img = bpy.data.images.new(name, width=res, height=res, alpha=True)
        img.colorspace_settings.name = colorspace
        zeros = np.zeros(res * res * 4, dtype=np.float32)
        img.pixels.foreach_set(zeros)
        return img

    def _save_image(self, img, out_dir):
        filepath = os.path.join(out_dir, img.name + ".png")
        img.filepath_raw = filepath
        img.file_format = 'PNG'
        img.save()

    # -------------------------------------------------------------
    # Merge one object's baked channel image straight into that
    # channel's running canvas, then free the temp image right away.
    # This is the key memory fix: instead of holding every object's
    # bake in RAM until the very end (N_objects x N_channels full-res
    # images at once - easily several GB and a common cause of
    # crashes on large scenes), peak extra memory now stays roughly
    # constant: one temp image + a handful of canvases, regardless of
    # object count.
    # -------------------------------------------------------------
    def _merge_and_free(self, key, img, res, colorspace, channel_data, out_dir, props):
        buf = np.empty(res * res * 4, dtype=np.float32)
        img.pixels.foreach_get(buf)
        arr = buf.reshape(res, res, 4)

        if props.keep_object_images:
            self._save_image(img, out_dir)

        entry = channel_data.get(key)
        if entry is None:
            entry = {'canvas': np.zeros((res, res, 4), dtype=np.float32), 'colorspace': colorspace}
            channel_data[key] = entry
        mask = arr[..., 3] > 0.0001
        entry['canvas'][mask] = arr[mask]

        bpy.data.images.remove(img)

    # -------------------------------------------------------------
    # Turn a channel's finished canvas array into a real Blender
    # image datablock (transparent PNG, ready to save).
    # -------------------------------------------------------------
    def _finalize_canvas(self, canvas, colorspace, name, res):
        existing = bpy.data.images.get(name)
        if existing is not None:
            bpy.data.images.remove(existing)
        combined = bpy.data.images.new(name, width=res, height=res, alpha=True)
        combined.colorspace_settings.name = colorspace
        combined.pixels.foreach_set(canvas.ravel())
        return combined

    # -------------------------------------------------------------
    # Build one shared material that reads the combined atlas images
    # through the new atlas UV map and wires them into a fresh
    # Principled BSDF.
    # -------------------------------------------------------------
    def _build_atlas_material(self, base_name, uv_name, combined_images):
        mat_name = f"{base_name}_AtlasMat"
        existing = bpy.data.materials.get(mat_name)
        if existing is not None:
            bpy.data.materials.remove(existing)

        mat = bpy.data.materials.new(mat_name)
        mat.use_nodes = True
        nt = mat.node_tree

        principled = get_principled_node(mat)
        output = get_output_node(mat)

        uv_node = nt.nodes.new('ShaderNodeUVMap')
        uv_node.uv_map = uv_name
        uv_node.location = (-800, 0)

        y_cursor = [400]

        def add_tex_node(image, label):
            node = nt.nodes.new('ShaderNodeTexImage')
            node.image = image
            node.label = label
            node.location = (-500, y_cursor[0])
            nt.links.new(uv_node.outputs['UV'], node.inputs['Vector'])
            y_cursor[0] -= 300
            return node

        if 'base_color' in combined_images:
            node = add_tex_node(combined_images['base_color'], 'Base Color')
            nt.links.new(node.outputs['Color'], principled.inputs['Base Color'])

        if 'roughness' in combined_images:
            node = add_tex_node(combined_images['roughness'], 'Roughness')
            nt.links.new(node.outputs['Color'], principled.inputs['Roughness'])

        if 'metallic' in combined_images:
            node = add_tex_node(combined_images['metallic'], 'Metallic')
            nt.links.new(node.outputs['Color'], principled.inputs['Metallic'])

        if 'normal' in combined_images:
            node = add_tex_node(combined_images['normal'], 'Normal')
            nmap = nt.nodes.new('ShaderNodeNormalMap')
            nmap.uv_map = uv_name
            nmap.location = (-200, node.location.y)
            nt.links.new(node.outputs['Color'], nmap.inputs['Color'])
            nt.links.new(nmap.outputs['Normal'], principled.inputs['Normal'])

        if 'displacement' in combined_images:
            node = add_tex_node(combined_images['displacement'], 'Displacement')
            disp = nt.nodes.new('ShaderNodeDisplacement')
            disp.location = (-200, node.location.y)
            nt.links.new(node.outputs['Color'], disp.inputs['Height'])
            nt.links.new(disp.outputs['Displacement'], output.inputs['Displacement'])

        return mat

    # -------------------------------------------------------------
    # Bake using the Emission-swap technique: for Base Color /
    # Roughness / Metallic / Displacement.
    # -------------------------------------------------------------
    def bake_channel_emit(self, context, obj, mat, source_socket, img, uv_name, original_uv_name):
        nt = mat.node_tree
        out = get_output_node(mat)

        emit = nt.nodes.new('ShaderNodeEmission')
        nt.links.new(source_socket, emit.inputs['Color'])

        old_surface_socket = None
        if out.inputs['Surface'].is_linked:
            old_surface_socket = out.inputs['Surface'].links[0].from_socket
        # temporarily route Emission into the material output
        for l in list(out.inputs['Surface'].links):
            nt.links.remove(l)
        nt.links.new(emit.outputs['Emission'], out.inputs['Surface'])

        img_node = nt.nodes.new('ShaderNodeTexImage')
        img_node.image = img
        for n in nt.nodes:
            n.select = False
        img_node.select = True
        nt.nodes.active = img_node

        # Bake TARGET (where pixels land in the atlas) always follows the
        # object's active UV map, so that must be the atlas UV.
        obj.data.uv_layers.active = obj.data.uv_layers[uv_name]

        # Bake SOURCE (which texel of the original textures gets read) must
        # stay on the original UV, not the atlas UV that's now active - so
        # every unconnected Image Texture node gets forced onto it here.
        temp_uv_node, temp_connected = wire_temp_source_uv(nt, original_uv_name, exclude_node=img_node)

        bpy.ops.object.select_all(action='DESELECT')
        obj.select_set(True)
        context.view_layer.objects.active = obj

        try:
            # use_clear is intentionally left False: the image was already
            # zero-filled (fully transparent) in _new_image, and a Clear here
            # would wipe the WHOLE canvas to opaque, not just reset it - which
            # is exactly what broke the transparency outside each UV island.
            bpy.ops.object.bake(type='EMIT', margin=int(self._props.pack_margin * 100), use_clear=False)
        finally:
            unwire_temp_source_uv(nt, temp_uv_node, temp_connected)
            # clean up and restore the original node setup
            nt.nodes.remove(emit)
            nt.nodes.remove(img_node)
            for l in list(out.inputs['Surface'].links):
                nt.links.remove(l)
            if old_surface_socket is not None:
                nt.links.new(old_surface_socket, out.inputs['Surface'])

    # -------------------------------------------------------------
    # Bake normals using the real NORMAL bake type.
    # -------------------------------------------------------------
    def bake_normal_type(self, context, obj, mat, img, uv_name, original_uv_name):
        nt = mat.node_tree
        img_node = nt.nodes.new('ShaderNodeTexImage')
        img_node.image = img
        for n in nt.nodes:
            n.select = False
        img_node.select = True
        nt.nodes.active = img_node

        # Same split as bake_channel_emit: active UV = atlas (bake target),
        # explicit temp wiring = original UV (bake source).
        obj.data.uv_layers.active = obj.data.uv_layers[uv_name]
        temp_uv_node, temp_connected = wire_temp_source_uv(nt, original_uv_name, exclude_node=img_node)

        bpy.ops.object.select_all(action='DESELECT')
        obj.select_set(True)
        context.view_layer.objects.active = obj

        try:
            # same reasoning as in bake_channel_emit: keep use_clear False so
            # the pre-zeroed transparent background outside the UV island
            # survives.
            bpy.ops.object.bake(type='NORMAL', margin=int(self._props.pack_margin * 100), use_clear=False)
        finally:
            unwire_temp_source_uv(nt, temp_uv_node, temp_connected)
            nt.nodes.remove(img_node)


# ---------------------------------------------------------------------------
# Sidebar Panel
# ---------------------------------------------------------------------------

class ATLASBAKE_PT_panel(Panel):
    bl_label = "Atlas Baker"
    bl_idname = "ATLASBAKE_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Atlas Baker"

    def draw(self, context):
        layout = self.layout
        props = context.scene.atlas_bake_props

        col = layout.column()
        col.prop(props, "output_dir")
        col.prop(props, "new_uv_name")
        col.prop(props, "image_base_name")
        col.prop(props, "resolution")
        col.prop(props, "pack_margin")

        box = layout.box()
        box.label(text="Channels")
        box.prop(props, "bake_base_color")
        box.prop(props, "bake_roughness")
        box.prop(props, "bake_metallic")
        box.prop(props, "bake_normal")
        box.prop(props, "bake_displacement")

        layout.separator()
        layout.prop(props, "keep_object_images")

        layout.separator()
        layout.operator("atlasbake.run", icon='RENDER_STILL')


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

classes = (
    AtlasBakeProperties,
    ATLASBAKE_OT_run,
    ATLASBAKE_PT_panel,
)


def register():
    for c in classes:
        bpy.utils.register_class(c)
    bpy.types.Scene.atlas_bake_props = PointerProperty(type=AtlasBakeProperties)


def unregister():
    del bpy.types.Scene.atlas_bake_props
    for c in reversed(classes):
        bpy.utils.unregister_class(c)


if __name__ == "__main__":
    register()
